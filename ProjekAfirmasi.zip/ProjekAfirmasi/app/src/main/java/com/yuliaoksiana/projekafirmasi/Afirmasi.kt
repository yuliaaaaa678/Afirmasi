package com.yuliaoksiana.projekafirmasi


data class Afirmasi(
    val imgAfirmasi: Int,
    val nameAfirrmasi: String,
    val descAfirmasi: String
)
